#!/usr/bin/env python
"""
Setup script for Celestial Intelligence
"""
from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""

setup(
    name="celestial-intelligence",
    version="1.0.0",
    long_description=long_description,
    long_description_content_type="text/markdown",
)

