# Distribution Guide for Celestial Intelligence

This guide explains how to package and distribute your application to end users.

## 📦 Distribution Methods

### 1. Simple Launcher Scripts (Easiest for Users)

**What users get:**
- The entire source code
- Simple `run.sh` (macOS/Linux) or `run.bat` (Windows) launcher
- Automatic setup on first run

**How to distribute:**
1. Create a ZIP of your project:
   ```bash
   zip -r CelestialIntelligence-Source.zip . \
     -x "*.git*" -x "*__pycache__*" -x "*.venv*" \
     -x "data/places.db*" -x "data/raw/*"
   ```

2. Users download and extract
3. Users run `./run.sh` (macOS/Linux) or `run.bat` (Windows)
4. Script handles everything automatically

**Pros:**
- ✅ Easy to update (just replace files)
- ✅ Users can see/modify source code
- ✅ Small download (~50 MB without database)

**Cons:**
- ❌ Requires Python installed
- ❌ First-time setup takes a few minutes

---

### 2. Standalone Executable (Best for Non-Technical Users)

**What users get:**
- Single executable or app bundle
- No Python installation needed
- Double-click to run

**How to build:**
```bash
./build_distribution.sh
```

This creates:
- `dist/CelestialIntelligence/` - Executable directory
- `dist/CelestialIntelligence-macOS-arm64.tar.gz` - Distribution archive

**How to distribute:**
1. Upload the `.tar.gz` file to your website/GitHub releases
2. Users download and extract
3. Users run the executable

**Platform-specific notes:**

**macOS:**
- Creates `CelestialIntelligence.app` bundle
- Users may need to right-click → Open (first time only) due to Gatekeeper
- Consider code signing for easier distribution

**Windows:**
- Creates `CelestialIntelligence.exe`
- Users may see Windows Defender warning (first time)
- Consider code signing for trusted distribution

**Linux:**
- Creates `CelestialIntelligence` binary
- May need to `chmod +x` before running

**Pros:**
- ✅ No Python installation needed
- ✅ Professional appearance
- ✅ Easy for non-technical users

**Cons:**
- ❌ Large file size (~200-300 MB)
- ❌ Need to build for each platform separately
- ❌ Database still needs to be downloaded on first run

---

### 3. Python Package (For Python Users)

**What users get:**
- Installable via pip
- Command-line tools: `celestial`, `celestial-web`

**How to build:**
```bash
python -m build
```

Creates: `dist/celestial_intelligence-1.0.0-py3-none-any.whl`

**How to distribute:**

**Option A: PyPI (Public)**
```bash
pip install twine
twine upload dist/*
```

Users install with:
```bash
pip install celestial-intelligence
```

**Option B: Direct Distribution**
Share the `.whl` file. Users install with:
```bash
pip install celestial_intelligence-1.0.0-py3-none-any.whl
```

**Pros:**
- ✅ Standard Python distribution
- ✅ Easy updates (`pip install --upgrade`)
- ✅ Integrates with Python ecosystem

**Cons:**
- ❌ Requires Python installed
- ❌ Users need to understand pip

---

### 4. Docker Container (For Server Deployment)

**What users get:**
- Containerized application
- Runs anywhere Docker is installed

**How to build:**
```bash
docker build -t celestial-intelligence:latest .
```

**How to distribute:**

**Option A: Docker Hub**
```bash
docker tag celestial-intelligence:latest yourusername/celestial-intelligence:latest
docker push yourusername/celestial-intelligence:latest
```

Users run with:
```bash
docker pull yourusername/celestial-intelligence
docker-compose up -d
```

**Option B: Save as file**
```bash
docker save celestial-intelligence:latest | gzip > celestial-intelligence-docker.tar.gz
```

Users load with:
```bash
docker load < celestial-intelligence-docker.tar.gz
docker-compose up -d
```

**Pros:**
- ✅ Consistent environment
- ✅ Easy server deployment
- ✅ Isolated from host system

**Cons:**
- ❌ Requires Docker installed
- ❌ Large image size (~1 GB)
- ❌ Overkill for desktop use

---

## 🎯 Recommended Distribution Strategy

### For General Users (Non-Technical)
**Use: Standalone Executable**

1. Build executables for each platform:
   ```bash
   # On macOS
   ./build_distribution.sh
   
   # On Windows
   pyinstaller celestial.spec
   
   # On Linux
   ./build_distribution.sh
   ```

2. Upload to GitHub Releases or your website

3. Provide simple instructions:
   - Download for your platform
   - Extract the archive
   - Run the executable
   - Database builds automatically on first run

### For Python Developers
**Use: Python Package**

1. Publish to PyPI:
   ```bash
   python -m build
   twine upload dist/*
   ```

2. Users install with:
   ```bash
   pip install celestial-intelligence
   celestial-web  # Launch web interface
   ```

### For Server Deployment
**Use: Docker**

1. Push to Docker Hub
2. Provide docker-compose.yml
3. Users run: `docker-compose up -d`

---

## 📝 Distribution Checklist

Before distributing, ensure:

- [ ] README.md is complete and accurate
- [ ] LICENSE file is included
- [ ] Version number is updated in pyproject.toml
- [ ] All dependencies are listed in requirements.txt
- [ ] Database builder works correctly
- [ ] Launcher scripts work on target platforms
- [ ] .gitignore excludes large files (database, raw data)
- [ ] Attribution for GeoNames data is included
- [ ] Test on clean system (no Python/dependencies installed)

---

## 🔄 Update Strategy

### For Source Distribution
Users pull latest code:
```bash
git pull
./run.sh  # Automatically updates dependencies
```

### For Executables
1. Build new version
2. Upload to releases
3. Users download and replace old version

### For Python Package
1. Increment version in pyproject.toml
2. Build and upload to PyPI
3. Users run: `pip install --upgrade celestial-intelligence`

### For Docker
1. Build new image
2. Push to Docker Hub with version tag
3. Users run: `docker-compose pull && docker-compose up -d`

---

## 💡 Tips for Better Distribution

### Reduce Download Size
- Don't include database in distribution (build on first run)
- Exclude .git directory
- Exclude __pycache__ and .venv
- Use .gitignore and MANIFEST.in properly

### Improve User Experience
- Auto-detect missing database and offer to build
- Show progress during database build
- Auto-open browser when web server starts
- Provide clear error messages

### Platform-Specific Considerations

**macOS:**
- Code sign the app to avoid Gatekeeper warnings
- Create a DMG for easier distribution
- Test on both Intel and Apple Silicon

**Windows:**
- Code sign the executable
- Create an installer with Inno Setup or NSIS
- Test on Windows 10 and 11

**Linux:**
- Provide .deb and .rpm packages
- Test on Ubuntu, Fedora, Arch
- Consider AppImage for universal distribution

---

## 📊 File Size Reference

| Component | Size | Notes |
|-----------|------|-------|
| Source code | ~5 MB | Without database |
| Ephemeris files | ~45 MB | Swiss Ephemeris data |
| Python dependencies | ~150 MB | When installed |
| Standalone executable | ~200-300 MB | Includes Python + deps |
| Places database | ~1.1 GB | Built on first run |
| GeoNames download | ~400 MB | Temporary, deleted after build |
| Docker image | ~800 MB | Without database |

**Total for end user:**
- Source distribution: ~50 MB download + 1.5 GB after setup
- Standalone executable: ~300 MB download + 1.1 GB after setup
- Docker: ~800 MB image + 1.1 GB database

---

## 🚀 Quick Commands Reference

```bash
# Build everything
./build_distribution.sh

# Build Python package only
python -m build

# Build executable only
pyinstaller celestial.spec

# Build Docker image
docker build -t celestial-intelligence .

# Test locally
./run.sh                    # Source distribution
dist/CelestialIntelligence/CelestialIntelligence  # Executable
docker-compose up           # Docker

# Create source archive for distribution
zip -r CelestialIntelligence-Source.zip . \
  -x "*.git*" -x "*__pycache__*" -x "*.venv*" \
  -x "data/places.db*" -x "data/raw/*"
```

---

**Questions?** Open an issue on GitHub or contact the maintainer.

