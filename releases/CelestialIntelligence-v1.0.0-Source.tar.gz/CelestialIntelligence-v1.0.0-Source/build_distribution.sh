#!/bin/bash
# Build distribution packages for Celestial Intelligence

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}📦 Building Celestial Intelligence${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo -e "${YELLOW}Creating virtual environment...${NC}"
    python3 -m venv .venv
fi

source .venv/bin/activate

# Install build tools
echo -e "${BLUE}Installing build tools...${NC}"
pip install --upgrade pip build wheel pyinstaller

# Clean previous builds
echo -e "${BLUE}Cleaning previous builds...${NC}"
rm -rf build/ dist/ *.egg-info/

# Build Python package
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}1️⃣  Building Python Package${NC}"
echo -e "${BLUE}========================================${NC}"
python -m build
echo -e "${GREEN}✓ Python package built: dist/*.whl${NC}"

# Build standalone executable
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}2️⃣  Building Standalone Executable${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${YELLOW}This may take several minutes...${NC}"
pyinstaller celestial.spec
echo -e "${GREEN}✓ Executable built: dist/CelestialIntelligence/${NC}"

# Create distribution archive
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}3️⃣  Creating Distribution Archive${NC}"
echo -e "${BLUE}========================================${NC}"

cd dist
if [ -d "CelestialIntelligence" ]; then
    # Determine OS for archive name
    OS_NAME=$(uname -s)
    ARCH=$(uname -m)
    
    case "$OS_NAME" in
        Darwin)
            PLATFORM="macOS"
            ;;
        Linux)
            PLATFORM="Linux"
            ;;
        *)
            PLATFORM="$OS_NAME"
            ;;
    esac
    
    ARCHIVE_NAME="CelestialIntelligence-${PLATFORM}-${ARCH}.tar.gz"
    
    tar -czf "$ARCHIVE_NAME" CelestialIntelligence/
    echo -e "${GREEN}✓ Archive created: dist/${ARCHIVE_NAME}${NC}"
fi

cd ..

# Summary
echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}✅ Build Complete!${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo "Distribution files created:"
echo ""
echo "📦 Python Package:"
ls -lh dist/*.whl 2>/dev/null | awk '{print "   " $9 " (" $5 ")"}'
echo ""
echo "🖥️  Standalone Executable:"
if [ -d "dist/CelestialIntelligence" ]; then
    echo "   dist/CelestialIntelligence/"
fi
echo ""
echo "📁 Distribution Archive:"
ls -lh dist/*.tar.gz 2>/dev/null | awk '{print "   " $9 " (" $5 ")"}'
echo ""
echo -e "${YELLOW}Note: Database (data/places.db) is NOT included.${NC}"
echo -e "${YELLOW}Users will build it on first run (~400 MB download).${NC}"
echo ""
echo "To test the executable:"
echo "  cd dist/CelestialIntelligence"
echo "  ./CelestialIntelligence"
echo ""

