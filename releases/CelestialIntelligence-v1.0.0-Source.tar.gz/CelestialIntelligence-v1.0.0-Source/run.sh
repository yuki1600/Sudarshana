#!/bin/bash
# Celestial Intelligence Launcher Script (macOS/Linux)

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}🌟 Celestial Intelligence${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is not installed!${NC}"
    echo "Please install Python 3.9 or higher from https://www.python.org/"
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo -e "${GREEN}✓${NC} Python $PYTHON_VERSION found"

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo -e "${YELLOW}⚙️  Creating virtual environment...${NC}"
    python3 -m venv .venv
    echo -e "${GREEN}✓${NC} Virtual environment created"
fi

# Activate virtual environment
source .venv/bin/activate

# Check if dependencies are installed
if ! python -c "import fastapi" &> /dev/null; then
    echo -e "${YELLOW}⚙️  Installing dependencies...${NC}"
    pip install --upgrade pip
    pip install -r requirements.txt
    echo -e "${GREEN}✓${NC} Dependencies installed"
fi

# Check if database exists
if [ ! -f "data/places.db" ]; then
    echo ""
    echo -e "${YELLOW}⚠️  Places database not found!${NC}"
    echo "The database is required for the application to work."
    echo "This is a one-time setup (~400 MB download, creates 1.1 GB database)."
    echo ""
    read -p "Build database now? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${BLUE}🔨 Building database...${NC}"
        python -m scripts.build_places_db --feature-class P
        echo -e "${GREEN}✓${NC} Database built successfully!"
    else
        echo -e "${RED}Cannot start without database.${NC}"
        echo "Run this command when ready: python -m scripts.build_places_db"
        exit 1
    fi
fi

echo ""
echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}🚀 Starting Celestial Intelligence...${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""
echo -e "Web UI:   ${GREEN}http://localhost:8000/ui${NC}"
echo -e "API Docs: ${GREEN}http://localhost:8000/docs${NC}"
echo ""
echo -e "${YELLOW}Press Ctrl+C to stop${NC}"
echo ""

# Launch the application
python -m src.launcher

