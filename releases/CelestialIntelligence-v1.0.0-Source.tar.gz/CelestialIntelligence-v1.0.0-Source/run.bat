@echo off
REM Celestial Intelligence Launcher Script (Windows)

setlocal enabledelayedexpansion

echo ========================================
echo 🌟 Celestial Intelligence
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed!
    echo Please install Python 3.9 or higher from https://www.python.org/
    pause
    exit /b 1
)

echo ✓ Python found

REM Check if virtual environment exists
if not exist ".venv" (
    echo ⚙️  Creating virtual environment...
    python -m venv .venv
    echo ✓ Virtual environment created
)

REM Activate virtual environment
call .venv\Scripts\activate.bat

REM Check if dependencies are installed
python -c "import fastapi" >nul 2>&1
if errorlevel 1 (
    echo ⚙️  Installing dependencies...
    python -m pip install --upgrade pip
    pip install -r requirements.txt
    echo ✓ Dependencies installed
)

REM Check if database exists
if not exist "data\places.db" (
    echo.
    echo ⚠️  Places database not found!
    echo The database is required for the application to work.
    echo This is a one-time setup (~400 MB download, creates 1.1 GB database^).
    echo.
    set /p BUILD_DB="Build database now? (y/n): "
    if /i "!BUILD_DB!"=="y" (
        echo 🔨 Building database...
        python -m scripts.build_places_db --feature-class P
        echo ✓ Database built successfully!
    ) else (
        echo Cannot start without database.
        echo Run this command when ready: python -m scripts.build_places_db
        pause
        exit /b 1
    )
)

echo.
echo ========================================
echo 🚀 Starting Celestial Intelligence...
echo ========================================
echo.
echo Web UI:   http://localhost:8000/ui
echo API Docs: http://localhost:8000/docs
echo.
echo Press Ctrl+C to stop
echo.

REM Launch the application
python -m src.launcher

pause

