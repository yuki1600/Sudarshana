# src/ci_core.py
from datetime import datetime, timedelta, date, timezone
from dateutil import tz
from timezonefinder import TimezoneFinder
import pandas as pd
import swisseph as swe

# ---------------------------------
# Sunrise/Sunset configuration
# ---------------------------------
# "vedic"        -> Sun's CENTER on the horizon, no refraction (Hindu/Vedic method)
# "astronomical" -> Apparent (upper limb) with standard refraction (almanac style)
# "geometric"    -> Center, no refraction (topocentric), non-Hindu
SUNRISE_DEFINITION = "vedic"   # default per your earlier preference
SITE_ELEVATION_M   = 0.0       # meters above sea level (set if you know site altitude)
PRESSURE_MBAR      = 1013.25   # used for "astronomical"
TEMP_C             = 15.0      # used for "astronomical"

# If your pyswisseph build exposes BIT_HINDU_RISING, use it; otherwise fall back.
HINDU_BIT = getattr(swe, "BIT_HINDU_RISING", None)

# ---------------------------------
# Constants / lookups
# ---------------------------------
RASHI_EN  = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"]
RASHI_SA  = ["Mesha","Vrishabha","Mithuna","Karka","Simha","Kanya","Tula","Vrischika","Dhanu","Makara","Kumbha","Meena"]
RASHI_ABR = ["Ar","Ta","Ge","Cn","Le","Vi","Li","Sc","Sg","Cp","Aq","Pi"]
NAK_NAMES = ["Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra","Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni","Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula","Purva Ashadha","Uttara Ashadha","Shravana","Dhanishtha","Shatabhisha","Purva Bhadrapada","Uttara Bhadrapada","Revati"]
YOGA_NAMES = ["Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda","Sukarma","Dhriti","Shoola","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana","Vajra","Siddhi","Vyatipat","Variyan","Parigha","Shiva","Siddha","Sadhya","Shubha","Shukla","Brahma","Indra","Vaidhriti"]
KARANA_MOV = ["Bava","Balava","Kaulava","Taitila","Gara","Vanija","Vishti"]
KARANA_FIXED = ["Kinstughna","Shakuni","Chatushpada","Naga"]
VARA_SA_MON_FIRST = ["Somavara","Mangalavara","Budhavara","Guruvara","Shukravara","Shanivara","Ravivara"]  # Mon..Sun
CHALDEAN = ["Saturn","Jupiter","Mars","Sun","Venus","Mercury","Moon"]  # planetary hour cycle

NAISARGIKA = {"Sun":60.0, "Moon":51.4, "Venus":42.9, "Jupiter":34.3, "Mercury":25.7, "Mars":17.1, "Saturn":8.6}
EXALT = {"Sun":("Aries",10.0),"Moon":("Taurus",3.0),"Mars":("Capricorn",28.0),"Mercury":("Virgo",15.0),"Jupiter":("Cancer",5.0),"Venus":("Pisces",27.0),"Saturn":("Libra",20.0)}
DEBIL={"Sun":("Libra",10.0),"Moon":("Scorpio",3.0),"Mars":("Cancer",28.0),"Mercury":("Pisces",15.0),"Jupiter":("Capricorn",5.0),"Venus":("Virgo",27.0),"Saturn":("Aries",20.0)}
MOOLATR={"Sun":("Leo",0.0,20.0),"Moon":("Taurus",0.0,3.0),"Mars":("Aries",0.0,12.0),"Mercury":("Virgo",15.0,20.0),"Jupiter":("Sagittarius",0.0,10.0),"Venus":"Libra 0-15","Saturn":("Aquarius",0.0,20.0)}
if isinstance(MOOLATR["Venus"], str):
    MOOLATR["Venus"] = ("Libra",0.0,15.0)

SIGN_INDEX = {name:i for i,name in enumerate(RASHI_EN)}
SIGN_LORD = {0:"Mars",1:"Venus",2:"Mercury",3:"Moon",4:"Sun",5:"Mercury",6:"Venus",7:"Mars",8:"Jupiter",9:"Saturn",10:"Saturn",11:"Jupiter"}
PERM_FRIENDS={"Sun":{"Moon","Mars","Jupiter"},"Moon":{"Sun","Mercury"},"Mars":{"Sun","Moon","Jupiter"},"Mercury":{"Sun","Venus"},"Jupiter":{"Sun","Moon","Mars"},"Venus":{"Mercury","Saturn"},"Saturn":{"Mercury","Venus"}}
PERM_ENEMIES={"Sun":{"Venus","Saturn"},"Moon":set(),"Mars":{"Mercury"},"Mercury":{"Moon"},"Jupiter":{"Venus","Mercury"},"Venus":{"Sun","Moon"},"Saturn":{"Sun","Moon","Mars"}}
BENEFICS={"Jupiter","Venus","Mercury"}; MALEFICS={"Saturn","Mars","Sun"}
MIN_SHADBALA_RUPA={"Sun":6.5,"Moon":6.0,"Mars":5.0,"Mercury":7.0,"Jupiter":6.5,"Venus":5.5,"Saturn":5.0}
DIG_MAX_ANGLE={"Sun":90.0,"Mars":90.0,"Jupiter":0.0,"Mercury":0.0,"Moon":180.0,"Venus":180.0,"Saturn":270.0}

PLANETS = {"Sun":swe.SUN,"Moon":swe.MOON,"Mars":swe.MARS,"Mercury":swe.MERCURY,"Jupiter":swe.JUPITER,"Venus":swe.VENUS,"Saturn":swe.SATURN,"Uranus":swe.URANUS,"Neptune":swe.NEPTUNE,"Pluto":swe.PLUTO}
GRAHAS_FOR_HOUSE = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu (true)","Ketu (true)"]

# ---------------------------------
# Tiny helpers
# ---------------------------------
_tf = TimezoneFinder()

def norm360(x): return x % 360.0
def lon_to_sign_idx(lon): return int(norm360(lon) // 30)

def dms_tuple(x):
    x = float(abs(x)); d = int(x); m_float = (x - d) * 60.0
    m = int(m_float); s = round((m_float - m) * 60.0)
    if s == 60: s = 0; m += 1
    if m == 60: m = 0; d += 1
    return d, m, s

def dms_str(x):
    d, m, s = dms_tuple(x); return f"{d:02d}°{m:02d}′{s:02d}″"

def sign_dms_str(lon):
    lon = norm360(lon); si = lon_to_sign_idx(lon); within = lon - 30*si
    return f"{RASHI_ABR[si]} {dms_str(within)}"

def rashi_name(lon): return RASHI_SA[lon_to_sign_idx(lon)]
def ordinal(n): return f"{n}{'th' if 11<=n%100<=13 else {1:'st',2:'nd',3:'rd'}.get(n%10,'th')}"
def fmt_dt(dt): return dt.strftime("%Y-%m-%d %H:%M:%S %Z")

def navamsa_for(lon):
    lon = norm360(lon); si = lon_to_sign_idx(lon); intra = lon - 30*si
    pada = int(intra // (30/9)) + 1
    movable = {0,3,6,9}; fixed = {1,4,7,10}; dual = {2,5,8,11}
    if si in movable: start = si
    elif si in fixed: start = (si + 8) % 12
    else:             start = (si + 4) % 12
    nsign = (start + (pada - 1)) % 12
    return nsign, pada

def tz_from_latlon(lat: float, lon: float) -> str:
    name = _tf.timezone_at(lat=lat, lng=lon) or _tf.certain_timezone_at(lat=lat, lng=lon)
    if not name:
        raise ValueError("Could not determine timezone for the given coordinates.")
    return name

# Updated to allow explicit tzname from the Places DB:
def local_and_utc(y, m, d, hh, mm, ss, lat, lon, tzname_override: str | None = None):
    """
    Build timezone-aware local and UTC datetimes.
    If tzname_override is provided, use that tz (e.g., 'Asia/Kolkata') instead of inferring from lat/lon.
    """
    if tzname_override:
        tzname = tzname_override
    else:
        tzname = tz_from_latlon(lat, lon)

    local_zone = tz.gettz(tzname)
    if local_zone is None:
        raise ValueError(f"Could not resolve timezone '{tzname}'")

    dt_local = datetime(y, m, d, hh, mm, ss, tzinfo=local_zone)
    dt_utc   = dt_local.astimezone(timezone.utc)
    tz_offset_hours = dt_local.utcoffset().total_seconds() / 3600.0
    return dt_local, dt_utc, tz_offset_hours, tzname, local_zone

# ---------------------------------
# Core
# ---------------------------------
def init_ephe(ephe_path="ephe", use_moseph=False, sidereal_mode=swe.SIDM_TRUE_PUSHYA):
    if not use_moseph:
        swe.set_ephe_path(ephe_path)
    swe.set_sid_mode(sidereal_mode)
    ephflag = swe.FLG_MOSEPH if use_moseph else swe.FLG_SWIEPH
    return ephflag | swe.FLG_SIDEREAL | swe.FLG_SPEED

def compute_chart(y, m, d, hh, mm, ss, lat, lon,
                  ephe_path="ephe", use_moseph=False, house_sys=b'O',
                  tzname_override: str | None = None):
    FLAGS = init_ephe(ephe_path, use_moseph)

    # time setup (with optional timezone override)
    local_dt, utc_dt, tz_offset_hours, tzname, LOCAL_ZONE = local_and_utc(
        y, m, d, hh, mm, ss, lat, lon, tzname_override=tzname_override
    )
    ut_hour  = utc_dt.hour + utc_dt.minute/60 + utc_dt.second/3600
    jd_ut    = swe.julday(utc_dt.year, utc_dt.month, utc_dt.day, ut_hour, swe.GREG_CAL)
    birth_date_local = date(y, m, d)

    # ---------------------------------
    # SUNRISE / SUNSET (Swiss Ephemeris) — robust across pyswisseph versions
    # ---------------------------------
    def _jd_to_local_dt(jd):
        # IMPORTANT: swe.revjul returns UT in HOURS, not fraction of a day.
        y_, m_, d_, ut_hours = swe.revjul(jd, swe.GREG_CAL)
        dt_utc = datetime(y_, m_, d_, tzinfo=timezone.utc) + timedelta(hours=ut_hours)
        return dt_utc.astimezone(LOCAL_ZONE)

    def _call_rise_trans(tjd, epheflag_for_rise, rsmi, geopos, atpress, attemp):
        """
        Try multiple pyswisseph signatures for rise_trans, from newest to oldest.
        Returns (retflag, values). Raises TypeError only if all signatures fail.
        """
        try:
            return swe.rise_trans(tjd, swe.SUN, "", epheflag_for_rise, rsmi, geopos, atpress, attemp)
        except TypeError:
            pass
        try:
            return swe.rise_trans(tjd, swe.SUN, "", epheflag_for_rise, rsmi, geopos, atpress)
        except TypeError:
            pass
        try:
            return swe.rise_trans(tjd, swe.SUN, "", epheflag_for_rise, rsmi, geopos)
        except TypeError:
            pass
        try:
            return swe.rise_trans(tjd, swe.SUN, rsmi, geopos, atpress, attemp)
        except TypeError:
            pass
        return swe.rise_trans(tjd, swe.SUN, rsmi, geopos)

    def _rsmi_for(mode):
        rsmi_rise = swe.CALC_RISE
        rsmi_set  = swe.CALC_SET
        atpress = PRESSURE_MBAR
        attemp  = TEMP_C
        if mode == "vedic":
            # center on horizon, no refraction (Hindu)
            if HINDU_BIT is not None:
                rsmi_rise |= HINDU_BIT
                rsmi_set  |= HINDU_BIT
                atpress, attemp = 0.0, 0.0
            else:
                rsmi_rise |= swe.BIT_DISC_CENTER | swe.BIT_NO_REFRACTION
                rsmi_set  |= swe.BIT_DISC_CENTER | swe.BIT_NO_REFRACTION
                atpress, attemp = 0.0, 0.0
        elif mode == "geometric":
            rsmi_rise |= swe.BIT_DISC_CENTER | swe.BIT_NO_REFRACTION
            rsmi_set  |= swe.BIT_DISC_CENTER | swe.BIT_NO_REFRACTION
            atpress, attemp = 0.0, 0.0
        # else: "astronomical" (default in this branch): upper limb + refraction
        return rsmi_rise, rsmi_set, atpress, attemp

    def _sunrise_sunset_for_anchor(anchor_jd_ut, lat_, lon_, elev_m, mode):
        """Compute next sunrise and next sunset AFTER the given UT JD anchor."""
        rsmi_rise, rsmi_set, atpress, attemp = _rsmi_for(mode)
        epheflag_for_rise = swe.FLG_MOSEPH if use_moseph else swe.FLG_SWIEPH
        geopos = (lon_, lat_, float(elev_m))
        ret_rise, val_rise = _call_rise_trans(anchor_jd_ut, epheflag_for_rise, rsmi_rise, geopos, atpress, attemp)
        if ret_rise < 0: raise RuntimeError("Sunrise computation failed.")
        ret_set,  val_set  = _call_rise_trans(anchor_jd_ut, epheflag_for_rise, rsmi_set,  geopos, atpress, attemp)
        if ret_set < 0: raise RuntimeError("Sunset computation failed.")
        return _jd_to_local_dt(val_rise[0]), _jd_to_local_dt(val_set[0])

    def _jd_ut_at_local_midnight(d_):
        """UT JD corresponding to local midnight at start of local date d_."""
        dt_local_mid = datetime(d_.year, d_.month, d_.day, 0, 0, 0, tzinfo=LOCAL_ZONE)
        dt_utc_mid = dt_local_mid.astimezone(timezone.utc)
        ut = dt_utc_mid.hour + dt_utc_mid.minute/60 + dt_utc_mid.second/3600
        return swe.julday(dt_utc_mid.year, dt_utc_mid.month, dt_utc_mid.day, ut, swe.GREG_CAL)

    def _sunrise_for_local_date(d_, lat_, lon_, elev_m, mode):
        """
        Return the sunrise whose LOCAL calendar date equals d_.
        Anchor at local midnight (converted to UT). If that still lands on the wrong
        calendar day due to edge cases, try anchors at ±1 day and choose the one
        whose LOCAL date equals d_.
        """
        anchors = [
            _jd_ut_at_local_midnight(d_ - timedelta(days=1)),
            _jd_ut_at_local_midnight(d_),
            _jd_ut_at_local_midnight(d_ + timedelta(days=1)),
        ]
        candidates = []
        for a in anchors:
            sr, _ = _sunrise_sunset_for_anchor(a, lat_, lon_, elev_m, mode)
            candidates.append(sr)
        for sr in candidates:
            if sr.date() == d_:
                return sr
        # fallback: choose the closest by local-date difference + time-of-day proximity
        return min(candidates, key=lambda t: abs((t.date() - d_).days) + abs((t - datetime(t.year, t.month, t.day, tzinfo=t.tzinfo)).total_seconds())/86400.0)

    def _sunset_for_local_date(d_, lat_, lon_, elev_m, mode):
        anchors = [
            _jd_ut_at_local_midnight(d_ - timedelta(days=1)),
            _jd_ut_at_local_midnight(d_),
            _jd_ut_at_local_midnight(d_ + timedelta(days=1)),
        ]
        candidates = []
        for a in anchors:
            _, ss = _sunrise_sunset_for_anchor(a, lat_, lon_, elev_m, mode)
            candidates.append(ss)
        for ss in candidates:
            if ss.date() == d_:
                return ss
        return min(candidates, key=lambda t: abs((t.date() - d_).days) + abs((t - datetime(t.year, t.month, t.day, tzinfo=t.tzinfo)).total_seconds())/86400.0)

    # Get sunrise/sunset for the requested local date (using requested definition)
    sunrise_local = _sunrise_for_local_date(birth_date_local, lat, lon, SITE_ELEVATION_M, SUNRISE_DEFINITION)
    sunset_local  = _sunset_for_local_date (birth_date_local, lat, lon, SITE_ELEVATION_M, SUNRISE_DEFINITION)
    # And bracketing sunrises for Hora partitioning
    sunrise_prev_local = _sunrise_for_local_date(birth_date_local - timedelta(days=1), lat, lon, SITE_ELEVATION_M, SUNRISE_DEFINITION)
    sunrise_next_local = _sunrise_for_local_date(birth_date_local + timedelta(days=1), lat, lon, SITE_ELEVATION_M, SUNRISE_DEFINITION)

    # ---------------------------------
    # Houses, ayanāṁśa
    # ---------------------------------
    cusps_trop, ascmc_trop = swe.houses(jd_ut, lat, lon, house_sys)
    ayan = swe.get_ayanamsa_ut(jd_ut)
    asc_sid = norm360(ascmc_trop[0] - ayan)
    mc_sid  = norm360(ascmc_trop[1] - ayan)

    # ---------------------------------
    # Planets / points
    # ---------------------------------
    def calc_vals(code): return swe.calc_ut(jd_ut, code, FLAGS)[0]

    rows=[]; numeric_lons={}
    for nm, lonv, label in [("Ascendant (1st House Cusp)", asc_sid, "Ascendant (1st House Cusp)"),
                            ("10th House Cusp", mc_sid, "10th House Cusp")]:
        nsi, pada = navamsa_for(lonv); nsi_name = RASHI_SA[nsi]
        rows.append({"Point": label,"Longitude (Sign DMS)": sign_dms_str(lonv),"Rashi": rashi_name(lonv),
                     "Navamsha": f"{nsi_name} {ordinal(pada)} Pada","Latitude (DMS)": "—","Speed (DMS/day)": "—"})
        numeric_lons[nm] = lonv

    for nm, code in PLANETS.items():
        vals = calc_vals(code); lonv, latv, spd = norm360(vals[0]), vals[1], vals[3]
        numeric_lons[nm] = lonv
        nsi, pada = navamsa_for(lonv); nsi_name = RASHI_SA[nsi]
        rows.append({"Point": nm,"Longitude (Sign DMS)": sign_dms_str(lonv),"Rashi": rashi_name(lonv),
                     "Navamsha": f"{nsi_name} {ordinal(pada)} Pada",
                     "Latitude (DMS)": f"{'N' if latv>=0 else 'S'} {dms_str(latv)}",
                     "Speed (DMS/day)": ("-" if spd<0 else "+")+dms_str(abs(spd))+"/day"})

    # true node
    try: vals_true = swe.calc_ut(jd_ut, swe.TRUE_NODE, FLAGS)[0]
    except Exception:
        vals_true = swe.nod_aps_ut(jd_ut, swe.MOON, FLAGS, swe.NODBIT_OSCU)[0]
    rahu = norm360(vals_true[0]); ketu = norm360(rahu+180)
    numeric_lons["Rahu (true)"] = rahu; numeric_lons["Ketu (true)"] = ketu
    for nm, lonv in [("Rahu (true)", rahu), ("Ketu (true)", ketu)]:
        nsi, pada = navamsa_for(lonv); nsi_name = RASHI_SA[nsi]
        rows.append({"Point": nm,"Longitude (Sign DMS)": sign_dms_str(lonv),"Rashi": rashi_name(lonv),
                     "Navamsha": f"{nsi_name} {ordinal(pada)} Pada","Latitude (DMS)": "—","Speed (DMS/day)": "—"})

    points_df = pd.DataFrame(rows)
    order_points = ["Ascendant (1st House Cusp)","10th House Cusp","Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Uranus","Neptune","Pluto","Rahu (true)","Ketu (true)"]
    points_df["__o__"] = points_df["Point"].apply(lambda x: order_points.index(x) if x in order_points else 999)
    points_df = points_df.sort_values("__o__").drop(columns="__o__").reset_index(drop=True)

    # ---------------------------------
    # Śrīpati (Porphyry) houses — spans between cusps
    # ---------------------------------
    def unwrap(seq):
        out=[seq[0]]
        for v in seq[1:]:
            pv=out[-1]
            if v<pv: v+=360.0
            out.append(v)
        return out

    def mid(a,b):
        if b<a: b+=360.0
        return (a+b)/2.0

    cusps_sid = [norm360(c - ayan) for c in cusps_trop]
    cusps_unw = unwrap(cusps_sid)
    starts, ends = [], []
    for i in range(12):
        cprev = cusps_unw[i-1] if i>0 else cusps_unw[-1]-360.0
        ci    = cusps_unw[i]
        cnext = cusps_unw[i+1] if i<11 else cusps_unw[0]+360.0
        s = mid(cprev, ci); e = mid(ci, cnext)
        starts.append(norm360(s)); ends.append(norm360(e))

    def arc_contains(start, end, x):
        start = norm360(start); end = norm360(end); x = norm360(x)
        return (start <= end and start <= x < end) or (start > end and (x >= start or x < end))

    house_occ = {i+1: [] for i in range(12)}
    for g in GRAHAS_FOR_HOUSE:
        glon = numeric_lons[g]
        found = 12
        for i in range(12):
            if arc_contains(starts[i], ends[i], glon): found = i+1; break
        house_occ[found].append(g.replace(" (true)",""))

    house_rows = [{"House": i+1,
                   "Start (Sign DMS)": sign_dms_str(starts[i]),
                   "Cusp (Sign DMS)":  sign_dms_str(cusps_sid[i]),
                   "End (Sign DMS)":   sign_dms_str(ends[i]),
                   "Occupants": ", ".join(house_occ[i+1]) if house_occ[i+1] else ""} for i in range(12)]
    houses_df = pd.DataFrame(house_rows).sort_values("House").reset_index(drop=True)

    # ---------------------------------
    # Vimśottarī (Mahādaśā only)
    # ---------------------------------
    NAK_STEP = 360.0/27.0
    MD_ORDER = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"]
    MD_YEARS = {"Ketu":7, "Venus":20, "Sun":6, "Moon":10, "Mars":7, "Rahu":18, "Jupiter":16, "Saturn":19, "Mercury":17}

    moon_lon = numeric_lons["Moon"]
    nak_index = int(moon_lon // NAK_STEP)
    frac_in   = (moon_lon - nak_index*NAK_STEP) / NAK_STEP
    frac_left = 1.0 - frac_in

    start_md_i = nak_index % 9
    start_md   = MD_ORDER[start_md_i]
    start_md_left_years = MD_YEARS[start_md] * frac_left

    def years_to_days(yf): return yf*365.25

    def build_vim_md(local_start):
        rows=[]; cur=local_start
        seq=[(start_md, start_md_left_years)]
        j=(start_md_i+1)%9; spent=start_md_left_years
        while spent < 120 - 1e-9:
            lord=MD_ORDER[j]; y2=MD_YEARS[lord]
            seq.append((lord,y2)); spent += y2; j=(j+1)%9
        for lord,yrs in seq:
            st=cur; en=st+timedelta(days=years_to_days(yrs))
            rows.append({"Mahadasa": lord,"Start (local)": st.strftime("%Y-%m-%d %H:%M:%S"),
                         "End (local)": en.strftime("%Y-%m-%d %H:%M:%S"),"Duration (years)": round(yrs,6)})
            cur=en
        return pd.DataFrame(rows)

    vim_md_df = build_vim_md(local_dt)

    # ---------------------------------
    # Yoginī (major)
    # ---------------------------------
    YOG_ORDER = ["Mangala","Pingala","Dhanya","Bhramari","Bhadrika","Ulka","Siddha","Sankata"]
    YOG_YEARS = {"Mangala":1,"Pingala":2,"Dhanya":3,"Bhramari":4,"Bhadrika":5,"Ulka":6,"Siddha":7,"Sankata":8}
    N2Y = {0:"Bhramari",1:"Bhadrika",2:"Ulka",3:"Siddha",4:"Sankata",5:"Mangala",6:"Pingala",7:"Dhanya",
           8:"Bhramari",9:"Bhadrika",10:"Ulka",11:"Siddha",12:"Sankata",13:"Mangala",14:"Pingala",15:"Dhanya",
           16:"Bhramari",17:"Bhadrika",18:"Ulka",19:"Siddha",20:"Sankata",21:"Mangala",22:"Pingala",23:"Dhanya",
           24:"Bhramari",25:"Bhadrika",26:"Ulka"}
    start_yog = N2Y[nak_index]

    def build_yogini(local_start, cycles=3):
        rows=[]; cur=local_start; yog_i=YOG_ORDER.index(start_yog)
        y1=YOG_YEARS[start_yog]*frac_left
        rows.append({"Yogini":YOG_ORDER[yog_i],
                     "Start (local)":cur.strftime("%Y-%m-%d %H:%M:%S"),
                     "End (local)":(cur+timedelta(days=years_to_days(y1))).strftime("%Y-%m-%d %H:%M:%S"),
                     "Duration (years)":round(y1,6)})
        cur+=timedelta(days=years_to_days(y1)); yog_i=(yog_i+1)%8
        for _ in range(cycles*8 - 1):
            lord=YOG_ORDER[yog_i]; y2=YOG_YEARS[lord]; end=cur+timedelta(days=years_to_days(y2))
            rows.append({"Yogini":lord,"Start (local)":cur.strftime("%Y-%m-%d %H:%M:%S"),
                         "End (local)":end.strftime("%Y-%m-%d %H:%M:%S"),"Duration (years)":round(y2,6)})
            cur=end; yog_i=(yog_i+1)%8
        return pd.DataFrame(rows)

    yogini_df = build_yogini(local_dt, cycles=3)

    # ---------------------------------
    # Pañcāṅga bits: Tithi/Nakṣatra/Yoga/Karaṇa + Hora
    # ---------------------------------
    def tithi_yoga_karana(jd_ut_):
        sun = norm360(swe.calc_ut(jd_ut_, swe.SUN, FLAGS)[0][0])
        moon = norm360(swe.calc_ut(jd_ut_, swe.MOON, FLAGS)[0][0])
        diff = norm360(moon - sun)
        tithi_num = int(diff // 12) + 1  # 1..30
        TITHI_NAMES = ["Pratipada","Dvitiya","Tritiya","Chaturthi","Panchami","Shashthi","Saptami","Ashtami","Navami","Dashami","Ekadashi","Dvadashi","Trayodashi","Chaturdashi","Purnima",
                       "Pratipada","Dvitiya","Tritiya","Chaturthi","Panchami","Shashthi","Saptami","Ashtami","Navami","Dashami","Ekadashi","Dvadashi","Trayodashi","Chaturdashi","Amavasya"]
        tname = TITHI_NAMES[tithi_num-1]
        paksha = "Shukla Paksha" if tithi_num <= 15 else "Krishna Paksha"
        if tithi_num == 15: tithi_disp = f"Purnima ({paksha.split()[0]})"
        elif tithi_num == 30: tithi_disp = f"Amavasya ({paksha.split()[0]})"
        else: tithi_disp = f"{paksha} {tname}"
        nak = NAK_NAMES[int(moon // (360/27))]
        yoga = YOGA_NAMES[int(norm360(moon + sun) // (360/27))]
        half_idx = int(diff // 6)  # 60 half-tithis
        if half_idx == 0: kar = KARANA_FIXED[0]
        elif half_idx >= 57: kar = KARANA_FIXED[half_idx-56]
        else: kar = KARANA_MOV[(half_idx-1) % 7]
        return dict(tithi=tithi_disp, nakshatra=nak, yoga=yoga, karana=kar)

    p = tithi_yoga_karana(jd_ut)

    # Hora — 24 seasonal horas between [sunrise → next sunrise); Hora0 = weekday lord
    def weekday_lord_from_pyweekday(py_weekday: int) -> str:
        # Python weekday: Mon=0..Sun=6
        return ["Moon","Mars","Mercury","Jupiter","Venus","Saturn","Sun"][py_weekday]

    def hora_lord_at_birth_seasonal_24(dt_local) -> str:
        if sunrise_local <= dt_local < sunrise_next_local:
            last_sr, next_sr = sunrise_local, sunrise_next_local
        elif dt_local < sunrise_local:
            last_sr, next_sr = sunrise_prev_local, sunrise_local
        else:
            last_sr = sunrise_next_local
            # compute the sunrise 2 days ahead (rare path when after next sunrise)
            next_sr = _sunrise_for_local_date(birth_date_local + timedelta(days=2), lat, lon, SITE_ELEVATION_M, SUNRISE_DEFINITION)

        span_sec = (next_sr - last_sr).total_seconds()
        hora_len = span_sec / 24.0
        idx = int(min(23, max(0, (dt_local - last_sr).total_seconds() // hora_len)))

        start_planet = weekday_lord_from_pyweekday(last_sr.weekday())
        start_idx = CHALDEAN.index(start_planet)
        return CHALDEAN[(start_idx + idx) % 7]

    hora_lord = hora_lord_at_birth_seasonal_24(local_dt)
    vara_name = VARA_SA_MON_FIRST[sunrise_local.weekday()]

    panchanga_df = pd.DataFrame([{
        "Sunrise (local)": fmt_dt(sunrise_local),
        "Next Sunrise":    fmt_dt(sunrise_next_local),
        "Vara (weekday)":  vara_name,
        "Tithi":           p['tithi'],
        "Nakshatra":       p['nakshatra'],
        "Yoga":            p['yoga'],
        "Karana":          p['karana'],
        "Hora":            hora_lord
    }])

    # ---------------------------------
    # Śaḍbala (compact implementation)
    # ---------------------------------
    def lon_deg(sign_name, deg): return SIGN_INDEX[sign_name]*30.0 + deg

    def uccha_bala(lon_, graha):
        if graha not in EXALT: return 0.0
        ex_sign, ex_deg = EXALT[graha]; ex = lon_deg(ex_sign, ex_deg)
        dist = min(abs(norm360(lon_-ex)), 360-abs(norm360(lon_-ex)))
        return max(0.0, 60.0*(1.0 - dist/180.0))

    MALE={"Sun","Mars","Jupiter","Saturn"}; FEMALE={"Moon","Venus"}

    def oja_yugma_bala(lon_, graha):
        sidx = lon_to_sign_idx(lon_); odd = (sidx % 2 == 0)
        d1 = 15.0 if (graha in MALE and odd) or (graha in FEMALE and not odd) else 0.0
        nsign,_ = navamsa_for(lon_); nodd=(nsign%2==0)
        d9 = 15.0 if (graha in MALE and nodd) or (graha in FEMALE and not nodd) else 0.0
        return 15.0 if graha=="Mercury" else d1 + d9

    def kendradi_bala(lon_):
        def _contains(start, end, x):
            start = norm360(start); end = norm360(end); x = norm360(x)
            return (start <= end and start <= x < end) or (start > end and (x >= start or x < end))
        h=12
        for i in range(12):
            if _contains(starts[i], ends[i], lon_): h=i+1; break
        return 60.0 if h in (1,4,7,10) else (30.0 if h in (2,5,8,11) else 15.0)

    def drekkana_bala(lon_, graha):
        si = lon_to_sign_idx(lon_); intra = lon_ - 30*si
        drek = int(intra//10) + 1; odd = (si%2==0)
        if graha in MALE: return 15.0 if (odd and drek==1) or ((not odd) and drek==3) else 0.0
        if graha in FEMALE: return 15.0 if (odd and drek==3) or ((not odd) and drek==1) else 0.0
        return 7.5

    def in_moolatrikona(graha, lon_):
        if graha not in MOOLATR: return False
        s,a,b=MOOLATR[graha]; si=SIGN_INDEX[s]; deg=norm360(lon_)-si*30.0
        if deg<0: deg+=360
        return 0<=deg<30 and (a<=deg<=b)

    SV_WEIGHTS = {"moolatrikona":45.0,"own":30.0,"great_friend":20.0,"friend":15.0,"neutral":10.0,"enemy":4.0,"great_enemy":2.0}

    def relation_to_lord(graha, lord):
        if lord in PERM_FRIENDS[graha] and graha in PERM_FRIENDS.get(lord,set()): return "great_friend"
        if lord in PERM_ENEMIES[graha] and graha in PERM_ENEMIES.get(lord,set()): return "great_enemy"
        if lord in PERM_FRIENDS[graha] or graha in PERM_FRIENDS.get(lord,set()): return "friend"
        if lord in PERM_ENEMIES[graha] or graha in PERM_ENEMIES.get(lord,set()): return "enemy"
        return "neutral"

    def varga_sign_D1(lon_): return lon_to_sign_idx(lon_)
    def varga_sign_D2(lon_):
        si=lon_to_sign_idx(lon_); intra=lon_-30*si; odd=(si%2==0)
        return 4 if (odd and intra<15) or ((not odd) and intra>=15) else 3
    def varga_sign_D3(lon_):
        si=lon_to_sign_idx(lon_); intra=lon_-30*si; return (si + int(intra//10))%12
    def varga_sign_D7(lon_):
        si=lon_to_sign_idx(lon_); intra=lon_-30*si; start=si if (si%2==0) else (si+6)%12
        return (start + int(intra//(30/7)))%12
    def varga_sign_D9(lon_): return navamsa_for(lon_)[0]
    def varga_sign_D12(lon_):
        si=lon_to_sign_idx(lon_); intra=lon_-30*si; return (si + int(intra//(30/12)))%12
    def varga_sign_D30(lon_):
        si=lon_to_sign_idx(lon_); intra=lon_-30*si; odd=(si%2==0)
        if odd:
            lord="Mars" if intra<5 else ("Saturn" if intra<10 else ("Jupiter" if intra<18 else ("Mercury" if intra<25 else "Venus")))
        else:
            lord="Venus" if intra<5 else ("Mercury" if intra<12 else ("Jupiter" if intra<20 else ("Saturn" if intra<25 else "Mars")))
        lord_to_sign={"Sun":4,"Moon":3,"Mars":0,"Mercury":2,"Jupiter":8,"Venus":1,"Saturn":10}
        return lord_to_sign[lord]

    def saptavargaja_bala(lon_, graha):
        v_funcs=[varga_sign_D1,varga_sign_D2,varga_sign_D3,varga_sign_D7,varga_sign_D9,varga_sign_D12,varga_sign_D30]
        total=0.0
        for vf in v_funcs:
            vs=vf(lon_); lord=SIGN_LORD[vs]
            if graha in EXALT and SIGN_INDEX[EXALT[graha][0]]==vs: total+=SV_WEIGHTS["own"]+15.0; continue
            if graha in DEBIL and SIGN_INDEX[DEBIL[graha][0]]==vs: total+=SV_WEIGHTS["enemy"]/2; continue
            if in_moolatrikona(graha, vs*30.0+1e-6): total+=SV_WEIGHTS["moolatrikona"]; continue
            total+= SV_WEIGHTS["own"] if lord==graha else SV_WEIGHTS[relation_to_lord(graha,lord)]
        return min(total,225.0)

    def angle_from_asc(lon_): return norm360(lon_ - asc_sid)
    def dig_bala(lon_, graha):
        tgt=DIG_MAX_ANGLE[graha]; ang=angle_from_asc(lon_)
        delta=min(abs(norm360(ang-tgt)), 360-abs(norm360(ang-tgt)))
        return max(0.0, 60.0*(1.0 - delta/180.0))

    def nathonnatha_bala(graha, speed):
        if speed<0: return 60.0
        MED={"Sun":0.9856,"Moon":13.1764,"Mars":0.524,"Mercury":1.2,"Jupiter":0.0831,"Venus":1.2,"Saturn":0.0335}
        r=min(speed/MED.get(graha,1.0),2.0)
        return max(0.0, min(60.0, 60.0*(r-0.5)))

    def paksha_bala(graha, moon_lon):
        sun_lon=numeric_lons["Sun"]; elong=norm360(moon_lon - sun_lon)
        frac=1 - abs(180-elong)/180
        return (60.0*frac) if graha in {"Jupiter","Venus","Mercury","Moon"} else (60.0*(1.0-frac) if graha in {"Saturn","Mars","Sun"} else 30.0)

    def tribhaga_bala(graha):
        # fraction within sunrise→next sunrise (or prev→today if before sunrise)
        if sunrise_local <= local_dt < sunrise_next_local:
            seg=(local_dt - sunrise_local).total_seconds()/(sunrise_next_local - sunrise_local).total_seconds()
        else:
            seg=(local_dt - sunrise_prev_local).total_seconds()/(sunrise_local - sunrise_prev_local).total_seconds()
        return 60.0 if seg<1/3 else (30.0 if seg<2/3 else 15.0)

    def abda_bala(graha):
        jan1=datetime(local_dt.year,1,1,0,0,0,tzinfo=LOCAL_ZONE)
        ylord=["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"][jan1.weekday()-1] if jan1.weekday()!=0 else "Sun"
        return 15.0 if graha==ylord else 0.0

    def maasa_bala(graha):
        sun_sign=lon_to_sign_idx(numeric_lons["Sun"]); lord=SIGN_LORD[sun_sign]
        return 15.0 if graha==lord else 0.0

    def vara_bala(graha):
        day_lord = ["Moon","Mars","Mercury","Jupiter","Venus","Saturn","Sun"][sunrise_local.weekday()]
        return 30.0 if graha==day_lord else 0.0

    def hora_bala(graha): return 15.0 if graha==hora_lord else 0.0

    def ayana_bala(graha):
        sun=numeric_lons["Sun"]; in_uttara = (sun>=270) or (sun<90)
        return 30.0 if ((in_uttara and graha in {"Sun","Mars","Jupiter","Saturn"}) or ((not in_uttara) and graha in {"Moon","Venus"})) else 0.0

    def yuddha_bala(graha):
        contenders=["Mars","Mercury","Jupiter","Venus","Saturn"]; my=numeric_lons[graha]; sc=0.0
        if graha in contenders:
            for o in contenders:
                if o==graha: continue
                if min(abs(my-numeric_lons[o]), 360-abs(my-numeric_lons[o])) < 1.0: sc+=15.0
        return sc

    def cheshta_bala(graha):
        spd=swe.calc_ut(jd_ut, getattr(swe, graha.upper()), FLAGS)[0][3]
        return nathonnatha_bala(graha, spd)

    def aspect_score(src_lon, tgt_lon, src_graha, orb=12.0):
        ang=norm360(tgt_lon - src_lon)
        def near(a):
            d=min(abs(norm360(ang-a)), 360-abs(norm360(ang-a)))
            return max(0.0, 1.0 - d/orb)
        allowed={0,180}
        if src_graha=="Jupiter": allowed|={120,240}
        if src_graha=="Mars":    allowed|={90,270}
        if src_graha=="Saturn":  allowed|={60,300}
        return max(near(a) for a in allowed)

    def drig_bala(graha, lon_, all_lons):
        total=0.0
        for other,olon in all_lons.items():
            if other not in ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"] or other==graha: continue
            s=aspect_score(olon, lon_, other, orb=12.0)
            if s<=0: continue
            if other in BENEFICS: total += 60.0*s
            if other in MALEFICS: total -= 60.0*s
        return max(-120.0, min(120.0, total))

    sb_rows=[]
    for g in ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"]:
        glon=numeric_lons[g]
        nai=float(NAISARGIKA[g])
        dig=float(dig_bala(glon,g))
        kal=float(nathonnatha_bala(g, swe.calc_ut(jd_ut, getattr(swe, g.upper()), FLAGS)[0][3])
                  + paksha_bala(g, numeric_lons["Moon"]) + tribhaga_bala(g) + abda_bala(g)
                  + maasa_bala(g) + vara_bala(g) + hora_bala(g) + ayana_bala(g) + yuddha_bala(g))
        che=float(cheshta_bala(g))
        dri=float(drig_bala(g, glon, numeric_lons))
        sth=float(uccha_bala(glon,g)+saptavargaja_bala(glon,g)+oja_yugma_bala(glon,g)+kendradi_bala(glon)+drekkana_bala(glon,g))
        total_v=sth+dig+kal+che+nai+dri
        total_r=total_v/60.0
        sb_rows.append({"Planet":g,"Sthana":round(sth,2),"Dig":round(dig,2),"Kala":round(kal,2),
                        "Cheshta":round(che,2),"Naisargika":round(nai,2),"Drig":round(dri,2),
                        "Total (Virupa)":round(total_v,2),"Total (Rupa)":round(total_r,3),
                        "Min Req (Rupa)":MIN_SHADBALA_RUPA[g],"Meets Min?":"Yes" if total_r>=MIN_SHADBALA_RUPA[g] else "No"})

    shadbala_df = pd.DataFrame(sb_rows)
    ranks = shadbala_df.set_index("Planet")["Total (Rupa)"].rank(method="dense", ascending=False).astype(int).to_dict()
    NATURAL_ORDER = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"]
    shadbala_df = shadbala_df.set_index("Planet").loc[NATURAL_ORDER].reset_index()
    shadbala_df["Rank"] = shadbala_df["Planet"].map(ranks)

    # ---------------------------------
    # Return everything
    # ---------------------------------
    return {
        "tzname": tzname,
        "local_dt": local_dt,
        "utc_dt": utc_dt,
        "jd_ut": jd_ut,
        "points": points_df,
        "houses": houses_df,
        "vimshottari_md": vim_md_df,
        "yogini": yogini_df,
        "shadbala": shadbala_df,
        "panchanga": panchanga_df,
    }

# Convenience wrapper when you already know the tz database name (e.g., from your places DB).
def compute_chart_with_tzname(y, m, d, hh, mm, ss, lat, lon, tzname,
                              ephe_path="ephe", use_moseph=False, house_sys=b'O'):
    return compute_chart(y, m, d, hh, mm, ss, lat, lon,
                         ephe_path=ephe_path, use_moseph=use_moseph, house_sys=house_sys,
                         tzname_override=tzname)
