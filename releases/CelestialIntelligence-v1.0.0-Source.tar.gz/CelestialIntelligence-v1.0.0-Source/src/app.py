# src/app.py
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import sqlite3
from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from src.ci_core import compute_chart_with_tzname

# ----- Absolute paths (robust no matter your working dir) -----
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "places.db"
EPHE_PATH = str(BASE_DIR / "ephe")
UI_DIR = BASE_DIR / "ui"

app = FastAPI(title="Celestial Intelligence API + UI")

# ----- DB helpers -----
def get_db():
    if not DB_PATH.exists():
        raise HTTPException(status_code=500, detail=f"places DB not found at {DB_PATH}. Did you run: python -m scripts.build_places_db ?")
    con = sqlite3.connect(str(DB_PATH))
    con.row_factory = sqlite3.Row
    return con

# ----- Models -----
class Country(BaseModel):
    iso2: str
    name: str

class Place(BaseModel):
    geonameid: int
    name: str
    admin1: Optional[str]
    country_iso2: str
    country_name: str
    lat: float
    lon: float
    timezone: str

# ----- Endpoints: countries / places -----
@app.get("/countries", response_model=List[Country])
def list_countries():
    con = get_db()
    try:
        rows = con.execute("SELECT iso2, name FROM countries ORDER BY name").fetchall()
    except sqlite3.OperationalError as e:
        raise HTTPException(status_code=500, detail=f"countries table missing: {e}")
    finally:
        con.close()
    return [Country(iso2=r["iso2"], name=r["name"]) for r in rows]

@app.get("/places", response_model=List[Place])
def search_places(
    country: str = Query(..., min_length=2, max_length=2, description="ISO2 country code, e.g. IN"),
    q: str = Query("", description="typeahead query (name/alternatenames)"),
    limit: int = Query(20, ge=1, le=100),
):
    con = get_db()
    cur = con.cursor()
    try:
        if q.strip():
            # Try FTS first
            try:
                fts_query = f'"{q.strip()}"'
                sql = """
                SELECT p.geonameid, p.name, p.asciiname, p.alternatenames,
                       p.lat, p.lon, p.country_iso2, p.admin1_code, p.population,
                       c.name as country_name, a.name as admin1_name, p.timezone
                FROM places_fts f
                JOIN places p ON p.geonameid = f.rowid
                LEFT JOIN countries c ON c.iso2 = p.country_iso2
                LEFT JOIN admin1 a ON a.key = p.country_iso2 || '.' || p.admin1_code
                WHERE p.country_iso2 = ?
                  AND f MATCH ?
                ORDER BY p.population DESC NULLS LAST
                LIMIT ?;
                """
                rows = cur.execute(sql, (country.upper(), fts_query, limit)).fetchall()
            except sqlite3.OperationalError:
                # FTS not available or table missing -> LIKE fallback
                like = f"%{q.strip()}%"
                sql = """
                SELECT p.geonameid, p.name, p.asciiname, p.alternatenames,
                       p.lat, p.lon, p.country_iso2, p.admin1_code, p.population,
                       c.name as country_name, a.name as admin1_name, p.timezone
                FROM places p
                LEFT JOIN countries c ON c.iso2 = p.country_iso2
                LEFT JOIN admin1 a ON a.key = p.country_iso2 || '.' || p.admin1_code
                WHERE p.country_iso2 = ?
                  AND (p.name LIKE ? OR p.asciiname LIKE ? OR p.alternatenames LIKE ?)
                ORDER BY p.population DESC NULLS LAST
                LIMIT ?;
                """
                rows = cur.execute(sql, (country.upper(), like, like, like, limit)).fetchall()
        else:
            # No query -> top cities by population
            sql = """
            SELECT p.geonameid, p.name, p.asciiname, p.alternatenames,
                   p.lat, p.lon, p.country_iso2, p.admin1_code, p.population,
                   c.name as country_name, a.name as admin1_name, p.timezone
            FROM places p
            LEFT JOIN countries c ON c.iso2 = p.country_iso2
            LEFT JOIN admin1 a ON a.key = p.country_iso2 || '.' || p.admin1_code
            WHERE p.country_iso2 = ?
            ORDER BY p.population DESC NULLS LAST
            LIMIT ?;
            """
            rows = cur.execute(sql, (country.upper(), limit)).fetchall()
    except sqlite3.OperationalError as e:
        raise HTTPException(status_code=500, detail=f"places query failed: {e}")
    finally:
        con.close()

    return [
        Place(
            geonameid=r["geonameid"],
            name=r["name"],
            admin1=r["admin1_name"],
            country_iso2=r["country_iso2"],
            country_name=r["country_name"],
            lat=float(r["lat"]),
            lon=float(r["lon"]),
            timezone=r["timezone"] or "UTC",
        )
        for r in rows
    ]

# ----- Endpoint: chart -----
@app.get("/chart")
def chart(
    date: str = Query(..., description="YYYY-MM-DD"),
    time: str = Query(..., description="HH:MM or HH:MM:SS (local time at place)"),
    lat: float = Query(...),
    lon: float = Query(...),
    tz: str = Query(..., description="IANA tz, e.g. Asia/Kolkata"),
    house_sys: str = Query("O", description="house system code; 'O' = Sripati/Porphyry"),
    moseph: bool = Query(False, description="use Moshier instead of Swiss (not recommended)"),
):
    try:
        if len(time.split(":")) == 2:
            time_s = time + ":00"
        else:
            time_s = time
        dt = datetime.strptime(f"{date} {time_s}", "%Y-%m-%d %H:%M:%S")
        y, m, d = dt.year, dt.month, dt.day
        hh, mm, ss = dt.hour, dt.minute, dt.second
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Bad date/time: {e}")

    try:
        res = compute_chart_with_tzname(
            y, m, d, hh, mm, ss,
            lat, lon, tz,
            ephe_path=EPHE_PATH, use_moseph=moseph, house_sys=house_sys.encode("ascii")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chart error: {e}")

    def dfrec(df): return df.to_dict(orient="records")
    payload = {
        "tzname": res["tzname"],
        "local_dt": str(res["local_dt"]),
        "utc_dt": str(res["utc_dt"]),
        "points": dfrec(res["points"]),
        "houses": dfrec(res["houses"]),
        "vimshottari_md": dfrec(res["vimshottari_md"]),
        "yogini": dfrec(res["yogini"]),
        "shadbala": dfrec(res["shadbala"]),
        "panchanga": dfrec(res["panchanga"]),
    }
    return JSONResponse(payload)

# ----- Serve the minimal UI under /ui -----
if not UI_DIR.exists():
    UI_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/ui", StaticFiles(directory=str(UI_DIR), html=True), name="ui")
