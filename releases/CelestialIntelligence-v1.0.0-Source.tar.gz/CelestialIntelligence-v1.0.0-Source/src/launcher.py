#!/usr/bin/env python
"""
Launcher script for Celestial Intelligence Web Interface
"""
from __future__ import annotations
import sys
import webbrowser
from pathlib import Path
from time import sleep
import subprocess


def check_database():
    """Check if the places database exists, offer to build it if not."""
    base_dir = Path(__file__).resolve().parent.parent
    db_path = base_dir / "data" / "places.db"
    
    if not db_path.exists():
        print("=" * 60)
        print("⚠️  Places database not found!")
        print("=" * 60)
        print("\nThe application requires a geographic database to function.")
        print("This is a one-time setup that will:")
        print("  • Download ~400 MB of data from GeoNames.org")
        print("  • Build a 1.1 GB database with 5.2M places")
        print("  • Take approximately 5-10 minutes")
        print("\nAttribution: City data © GeoNames (CC-BY 4.0)")
        print("=" * 60)
        
        response = input("\nWould you like to build the database now? (y/n): ").strip().lower()
        
        if response == 'y':
            print("\n🔨 Building database... Please wait.\n")
            try:
                from scripts.build_places_db import main as build_db
                build_db()
                print("\n✅ Database built successfully!")
                return True
            except Exception as e:
                print(f"\n❌ Error building database: {e}")
                print("\nYou can manually build it later by running:")
                print("  python -m scripts.build_places_db")
                return False
        else:
            print("\n⚠️  Cannot start without database.")
            print("Run this command when ready:")
            print("  python -m scripts.build_places_db")
            return False
    
    return True


def launch_web(host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True):
    """Launch the web interface."""
    
    # Check database first
    if not check_database():
        sys.exit(1)
    
    print("=" * 60)
    print("🌟 Celestial Intelligence - Web Interface")
    print("=" * 60)
    print(f"\n🚀 Starting server at http://{host}:{port}")
    print(f"📊 API docs available at http://{host}:{port}/docs")
    print(f"🎨 Web UI available at http://{host}:{port}/ui")
    print("\n💡 Press Ctrl+C to stop the server")
    print("=" * 60)
    
    # Open browser after a short delay
    if open_browser:
        def open_browser_delayed():
            sleep(2)
            webbrowser.open(f"http://{host}:{port}/ui")
        
        import threading
        threading.Thread(target=open_browser_delayed, daemon=True).start()
    
    # Launch uvicorn
    try:
        import uvicorn
        uvicorn.run(
            "src.app:app",
            host=host,
            port=port,
            log_level="info",
            access_log=True
        )
    except KeyboardInterrupt:
        print("\n\n👋 Shutting down gracefully...")
    except Exception as e:
        print(f"\n❌ Error starting server: {e}")
        sys.exit(1)


def main():
    """Main entry point for the launcher."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Celestial Intelligence Web Interface Launcher"
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)"
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Don't automatically open browser"
    )
    
    args = parser.parse_args()
    
    launch_web(
        host=args.host,
        port=args.port,
        open_browser=not args.no_browser
    )


if __name__ == "__main__":
    main()

