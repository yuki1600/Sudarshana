# 🌟 Celestial Intelligence

A comprehensive Vedic Astrology (Jyotish) birth chart calculator with a database of 5.2 million places worldwide.

## ✨ Features

- 🌍 **5.2 Million Places Database** - Comprehensive geographic data from GeoNames
- 🔍 **Fast Full-Text Search** - Find any city, town, or village instantly
- 📊 **Complete Vedic Calculations** - Pañcāṅga, Vimśottarī Daśā, Yoginī Daśā, Śaḍbala
- 🏠 **Multiple House Systems** - Śrīpati/Porphyry and more
- 🌐 **Web Interface** - Modern, responsive UI
- 💻 **CLI Interface** - Terminal-based for power users
- 🐳 **Docker Support** - Easy containerized deployment
- 📦 **Standalone Executables** - No Python installation required

## 🚀 Quick Start

### Option 1: Simple Launcher (Recommended)

**macOS/Linux:**
```bash
./run.sh
```

**Windows:**
```
run.bat
```

The launcher will:
1. Check for Python installation
2. Create a virtual environment
3. Install dependencies
4. Offer to build the database (one-time setup)
5. Launch the web interface at http://localhost:8000/ui

### Option 2: Manual Setup

1. **Install Python 3.9+** from https://www.python.org/

2. **Clone or download this repository**

3. **Create virtual environment:**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```

4. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Build the places database (one-time, ~5-10 minutes):**
   ```bash
   python -m scripts.build_places_db --feature-class P
   ```
   This downloads ~400 MB from GeoNames and creates a 1.1 GB database.

6. **Launch the application:**
   
   **Web Interface:**
   ```bash
   python -m src.launcher
   ```
   Then open http://localhost:8000/ui
   
   **CLI Interface:**
   ```bash
   python -m src.main
   ```

### Option 3: Docker

1. **Build and setup:**
   ```bash
   docker-compose build
   docker-compose --profile setup run --rm db-builder
   ```

2. **Run:**
   ```bash
   docker-compose up -d
   ```

3. **Access:**
   - Web UI: http://localhost:8000/ui
   - API Docs: http://localhost:8000/docs

## 📦 Installation Methods

### Method 1: Python Package (Coming Soon)

```bash
pip install celestial-intelligence
celestial-web  # Launch web interface
celestial      # Launch CLI
```

### Method 2: Standalone Executable

Download the pre-built executable for your platform:
- **macOS**: `CelestialIntelligence.app`
- **Windows**: `CelestialIntelligence.exe`
- **Linux**: `CelestialIntelligence`

No Python installation required!

**To build yourself:**
```bash
pip install pyinstaller
pyinstaller celestial.spec
```

The executable will be in `dist/CelestialIntelligence/`

### Method 3: From Source

See "Option 2: Manual Setup" above.

## 📖 Usage

### Web Interface

1. Launch: `python -m src.launcher` or `./run.sh`
2. Open browser to http://localhost:8000/ui
3. Select country and city
4. Enter birth date and time
5. View complete birth chart with all calculations

### CLI Interface

```bash
python -m src.main --country IN --city Bangalore --date 1990-01-15 --time 14:30:00
```

**Options:**
- `--country`: Country code (e.g., IN, US, GB) or name
- `--city`: City name (partial match supported)
- `--date`: Birth date (YYYY-MM-DD)
- `--time`: Birth time (HH:MM:SS, local time)
- `--house_sys`: House system (default: O for Śrīpati/Porphyry)
- `--ephe`: Path to ephemeris files (default: ./ephe)

### API

The web interface also provides a REST API:

**Endpoints:**
- `GET /countries` - List all countries
- `GET /places?country=IN&q=Bang` - Search places
- `GET /chart?date=1990-01-15&time=14:30:00&lat=12.97&lon=77.59&tz=Asia/Kolkata` - Calculate chart

**Documentation:** http://localhost:8000/docs

## 🗂️ Project Structure

```
celestial-intelligence/
├── src/
│   ├── main.py          # CLI interface
│   ├── app.py           # FastAPI web application
│   ├── launcher.py      # Web launcher with auto-setup
│   └── ci_core.py       # Core calculation engine
├── scripts/
│   └── build_places_db.py  # Database builder
├── ui/
│   └── index.html       # Web interface
├── ephe/                # Swiss Ephemeris data files
├── data/
│   ├── places.db        # Places database (built on first run)
│   └── raw/             # Downloaded GeoNames data
├── run.sh               # macOS/Linux launcher
├── run.bat              # Windows launcher
├── Dockerfile           # Docker configuration
├── docker-compose.yml   # Docker Compose configuration
├── celestial.spec       # PyInstaller spec for executables
├── pyproject.toml       # Python package configuration
└── requirements.txt     # Python dependencies
```

## 🔧 Configuration

### Database Options

Build with different feature classes:

```bash
# Populated places only (5.2M records, 1.1 GB) - Recommended
python -m scripts.build_places_db --feature-class P

# All features (12M+ records, 2+ GB) - Not recommended
python -m scripts.build_places_db --feature-class ALL
```

### House Systems

Supported house systems (use with `--house_sys` flag):
- `O` - Śrīpati/Porphyry (default)
- `P` - Placidus
- `K` - Koch
- `R` - Regiomontanus
- `C` - Campanus
- `E` - Equal
- And more...

## 📊 Data Attribution

- **Geographic Data**: © [GeoNames](https://www.geonames.org/) (CC-BY 4.0)
- **Ephemeris**: Swiss Ephemeris by Astrodienst

## 🛠️ Development

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black src/ scripts/
```

### Building Distribution

**Python Package:**
```bash
python -m build
pip install dist/celestial_intelligence-1.0.0-py3-none-any.whl
```

**Executable:**
```bash
pyinstaller celestial.spec
```

**Docker Image:**
```bash
docker build -t celestial-intelligence:latest .
```

## 🐛 Troubleshooting

### Database not found
Run: `python -m scripts.build_places_db --feature-class P`

### Import errors
Make sure you're in the virtual environment:
```bash
source .venv/bin/activate  # macOS/Linux
.venv\Scripts\activate     # Windows
```

### Port already in use
Change the port:
```bash
python -m src.launcher --port 8080
```

### Slow database build
This is normal - downloading 400 MB and processing 5.2M records takes time.
Use curl to download manually if needed (see scripts/build_places_db.py).

## 📝 License

MIT License - See LICENSE file for details

## 🤝 Contributing

Contributions welcome! Please open an issue or pull request.

## 📧 Contact

For questions or support, please open an issue on GitHub.

---

**Made with ❤️ for the Jyotish community**

