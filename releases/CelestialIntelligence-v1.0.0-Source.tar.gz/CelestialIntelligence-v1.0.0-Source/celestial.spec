# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for Celestial Intelligence
Creates a standalone executable with all dependencies bundled.

Usage:
    pyinstaller celestial.spec

This will create:
    - dist/CelestialIntelligence/ (directory with executable and data)
    - dist/CelestialIntelligence.app (on macOS)
    - dist/CelestialIntelligence.exe (on Windows)
"""

from PyInstaller.utils.hooks import collect_data_files, collect_submodules
import os
from pathlib import Path

block_cipher = None

# Collect all pyswisseph data files
swisseph_datas = collect_data_files('swisseph')

# Add our ephemeris files
ephe_files = []
ephe_dir = Path('ephe')
if ephe_dir.exists():
    for f in ephe_dir.glob('*.se1'):
        ephe_files.append((str(f), 'ephe'))

# Add UI files
ui_files = []
ui_dir = Path('ui')
if ui_dir.exists():
    for f in ui_dir.glob('*'):
        if f.is_file():
            ui_files.append((str(f), 'ui'))

# Add database if it exists (optional - can be downloaded on first run)
data_files = []
db_path = Path('data/places.db')
if db_path.exists():
    data_files.append(('data/places.db', 'data'))

# Combine all data files
datas = swisseph_datas + ephe_files + ui_files + data_files

# Hidden imports that PyInstaller might miss
hiddenimports = [
    'uvicorn.logging',
    'uvicorn.loops',
    'uvicorn.loops.auto',
    'uvicorn.protocols',
    'uvicorn.protocols.http',
    'uvicorn.protocols.http.auto',
    'uvicorn.protocols.websockets',
    'uvicorn.protocols.websockets.auto',
    'uvicorn.lifespan',
    'uvicorn.lifespan.on',
    'pandas',
    'pandas._libs',
    'pandas._libs.tslibs',
    'timezonefinder',
    'fastapi',
    'starlette',
    'pydantic',
]

# Analysis for the web launcher
a_web = Analysis(
    ['src/launcher.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# Analysis for the CLI
a_cli = Analysis(
    ['src/main.py'],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports + ['src.ci_core'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# Merge the two analyses
MERGE((a_web, 'celestial-web', 'celestial-web'), (a_cli, 'celestial-cli', 'celestial-cli'))

# Build the web executable
pyz_web = PYZ(a_web.pure, a_web.zipped_data, cipher=block_cipher)

exe_web = EXE(
    pyz_web,
    a_web.scripts,
    [],
    exclude_binaries=True,
    name='CelestialIntelligence',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,  # Set to False for GUI-only mode
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # Add your icon file here: icon='icon.ico' or icon='icon.icns'
)

# Build the CLI executable
pyz_cli = PYZ(a_cli.pure, a_cli.zipped_data, cipher=block_cipher)

exe_cli = EXE(
    pyz_cli,
    a_cli.scripts,
    [],
    exclude_binaries=True,
    name='celestial-cli',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

# Collect everything into a directory
coll = COLLECT(
    exe_web,
    a_web.binaries,
    a_web.zipfiles,
    a_web.datas,
    exe_cli,
    a_cli.binaries,
    a_cli.zipfiles,
    a_cli.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='CelestialIntelligence',
)

# On macOS, create an app bundle
import sys
if sys.platform == 'darwin':
    app = BUNDLE(
        coll,
        name='CelestialIntelligence.app',
        icon=None,  # Add your icon: icon='icon.icns'
        bundle_identifier='com.celestialintelligence.app',
        info_plist={
            'NSPrincipalClass': 'NSApplication',
            'NSHighResolutionCapable': 'True',
        },
    )

